Use a habilidade contar-termos.

Neste grupo focal (o arquivo anexo), quantas vezes cada participante falou de preço, de atraso, de bagagem e de atendimento?

Não conte a moderadora. Quero uma tabela: uma linha por pessoa, uma coluna por tema, e o total de cada tema.
